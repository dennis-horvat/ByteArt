import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-picture',
  templateUrl: './change-picture.component.html',
  styleUrls: ['./change-picture.component.css']
})
export class ChangePictureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
